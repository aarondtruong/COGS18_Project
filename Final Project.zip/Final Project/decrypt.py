def decrypt():
    
    op = open('/Users/Aaron/Desktop/encrypted_file.txt', 'rb')

    encr_file = op.read()

    op.close()

    encr_file = bytearray(encr_file)

    
#This is where you enter your key from earlier. 
    key = 199

    for index, value in enumerate(encr_file):
        encr_file[index] = value^key


    op = open('decrypted_file.txt', 'wb')

    op.write(encr_file)

    op.close()
    

decrypt()