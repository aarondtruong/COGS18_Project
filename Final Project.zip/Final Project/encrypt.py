##Encrypt your file here:

#Open the file by adding its path into the string below.
#Remember to use YOUR directory, not mine below

def encrypt():
    op = open('/Users/Aaron/Desktop/new_file.txt', 'rb')

    encr_file = op.read()

    op.close()

    encr_file = bytearray(encr_file)


#This is where you choose your unique key for decrypting later. 
#It can be any digit from 0-255.

    key = 199

    for index, value in enumerate(encr_file):
        encr_file[index] = value^key

    
    op = open('encrypted_file.txt', 'wb')

    op.write(encr_file)

    op.close()
    
    
encrypt()